
class PacketTableModel {
    Packet [] packetArray;
    int column = 3;
    int row = 2;
    int size = 0;
    boolean b;
    public PacketTableModel (Packet [] packetArray, boolean b){
        this.b = b;
        this.packetArray = packetArray;
        for (Packet p : packetArray){
            size += p.getIpPacketSize();
            row++;
        }
    }
    
    public int getColumnCount() {
        return column;
    }
    
    public int getRowCount(){
        return row;
    }
    
    public Object getValueAt(int x, int y){
        Object obj = "";
        if (x<row-2){
            Packet p = packetArray[x];
            if (y==0){
               obj = p.getTimeStamp();
            }
            else if (y == 2){
               obj = p.getIpPacketSize();
            }
            else if (y == 1){
                if (b == true){obj = p.getDestinationHost();}
                else {obj = p.getSourceHost();}
            }
        }
        else{
            if (x == row-2){
                obj = size;
            }
            else if (x == row - 1){
                obj = (double)size/(row-2);
            }
        }
            
            return obj;
    }
}