
class Host implements Comparable<Host>{
    private String ip;
    public Host(String ip){
        this.ip = ip;
    }
    public String toString(){
        return ip;
    }
    public String getIp(){
        return ip;
    }
    public int compareTo(Host other){
        String[] ip1 = this.ip.split("\\.");
        String formatted1 = String.format("%3s.%3s.%3s.%3s", ip1[0],ip1[1],ip1[2],ip1[3]);
        String[] ip2 = other.getIp().split("\\.");
        String formatted2 = String.format("%3s.%3s.%3s.%3s",  ip2[0],ip2[1],ip2[2],ip2[3]);
        return formatted1.compareTo(formatted2);
       
    }
}