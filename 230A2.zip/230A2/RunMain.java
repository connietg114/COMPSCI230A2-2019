import javax.swing.*;
public class RunMain implements Runnable {

	public void run() {
		A2Frame frame = new A2Frame();
	}
	
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new RunMain());
	}

}

