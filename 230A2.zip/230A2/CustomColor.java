import java.awt.Color;
import java.awt.Component;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class CustomColor extends DefaultTableCellRenderer{
	int colorRow;
	
	public void setColorRow (int row) {
		colorRow = row;
	}
	//change the color of last 2 rows
	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
		if (row == colorRow -2) {
			setBackground(Color.yellow);
		}else if(row == colorRow-1) {
			setBackground(Color.blue);
		}
		else {
			setBackground(Color.white);
		}
		
		return super.getTableCellRendererComponent(table, value, isSelected, hasFocus,
                row, column);
		
	}
	
}
