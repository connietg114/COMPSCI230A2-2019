
class Packet {
    private String sourceHost;
    private String destHost;
    private double timeStamp;
    private int ipPacketSize;
    
    public Packet(String s){
        String [] splitS = s.split("\t", -1);
        
        sourceHost = splitS[2].matches("^((0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)\\.){3}(0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)$")?splitS[2] : "";
        destHost = splitS[4].matches("^((0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)\\.){3}(0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)$")?splitS[4] : "";
        timeStamp = Double.parseDouble(splitS[1]);
        ipPacketSize = splitS[7].matches("\\d+")?Integer.parseInt(splitS[7]) : 0;
            
    }
    public String getSourceHost(){
        return sourceHost;
    }
    public String getDestinationHost(){
        return destHost;
    }
    public double getTimeStamp(){
        return timeStamp;
    }
    public int getIpPacketSize(){
        return ipPacketSize;
    }
    public void setSourceHost(String sH){
        sourceHost = sH;
    }
    public void setDestinationHost(String dH){
        destHost = dH;
    }
    public void setTimeStamp(double tS){
        timeStamp = tS;
    }
    public void setIpPacketSize(int size){
        ipPacketSize = size;
    }
    public String toString(){
        return "src=" + sourceHost + ", dest=" + destHost + ", time=" + String.format("%.2f", timeStamp) + ", size=" +ipPacketSize;
    }
}