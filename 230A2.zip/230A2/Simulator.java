import java.io.*;
import java.util.*;
public class Simulator {
    ArrayList<Packet> packetList = new ArrayList<Packet>();
    ArrayList<String> packetStringList = new ArrayList<String>();
    File f;
    public Simulator (File f){
        try {
            String line;
            Scanner in = new Scanner(f);
            while(in.hasNext()){
                line = in.nextLine();
                String [] splitS = line.split("\t", -1);
                if(splitS[2].matches("^((0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)\\.){3}(0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)$")){
		            packetStringList.add(line);
		        }
            }
        }
        catch(FileNotFoundException e) {
			System.out.println(e);
		}
        this.f = f;
    }
    public ArrayList<Packet> getValidPackets() {
        for (String s : packetStringList){
            packetList.add(new Packet(s));
        }
	return packetList;	
    }
    
    public Object[] getUniqueSortedSourceHosts(){
        Set<String> hostList = new HashSet<String>();
        ArrayList<Host> sortedHostList = new ArrayList<Host>();
    
        for(Packet p : getValidPackets()){
            if(p.getSourceHost().matches("^((0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)\\.){3}(0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)$")){
                hostList.add(p.getSourceHost());
            }
        }
        for(String host : hostList){
            sortedHostList.add(new Host(host));
        }
        Collections.sort(sortedHostList);
        return sortedHostList.toArray();
    }
    
    public Object[] getUniqueSortedDestHosts(){
        Set<String> destList = new HashSet<String>();
        ArrayList<Host> sortedDestList = new ArrayList<Host>();
    
        for(Packet p : getValidPackets()){
            if(p.getSourceHost().matches("^((0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)\\.){3}(0|1\\d?\\d?|2[0-4]?\\d?|25[0-5]?|[3-9]\\d?)$")){
                destList.add(p.getDestinationHost());
            }
        }
        for(String dest : destList){
            sortedDestList.add(new Host(dest));
        }
        Collections.sort(sortedDestList);
        return sortedDestList.toArray();
    } 
    
    public Packet[] getTableData(String ip, boolean isSrcHost){
        ArrayList<Packet> sortedList = new ArrayList<Packet>();
        if (isSrcHost == true){
            for (Packet p : getValidPackets()){
                if (p.getSourceHost().matches(ip)){
                    sortedList.add(p);
                }
            }
        }
        else{
            for (Packet p : getValidPackets()){
                if (p.getDestinationHost().matches(ip)){
                    sortedList.add(p);
                }
            }
        }
    Packet[] packetArray = new Packet[sortedList.size()];
    packetArray = sortedList.toArray(packetArray);
    return  packetArray;
    } 
    
}