import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import java.io.*;

public class A2Frame extends JFrame{
	JFrame frame;
	JMenuBar menuBar;
	Container contentPane;
	JMenu fileMenu, quitMenu;
	
	JFileChooser fc;
	
	JPanel radioButtonPanel;
	JRadioButton radioButtonSource;
	JRadioButton radioButtonDest;
	ButtonGroup radioButtonGroup;
	
	Font font1 = new Font("Arial", Font.BOLD, 500);
	
	Boolean isSrcHost = true;
	
	Simulator readFile;
	
	JComboBox<String> srcHostComboBox ; 
	JComboBox<String> destHostComboBox ; 
	JPanel comboBoxPanel = new JPanel();
	
	Object[] srcHostArr = new Object[0];
	Object[] destHostArr = new Object[0];
	
	ArrayList<Packet> packetArrayList = new ArrayList<Packet>();
	Packet [] srcPacketList = new Packet[0];
	Packet [] destPacketList = new Packet[0];
	
	JPanel srcTablePanel= new JPanel();
	JPanel destTablePanel= new JPanel();
	JTable srcTable;
	JTable destTable;
	String sourceIpSelected;
	PacketTableModel srcPacketTableData;
	PacketTableModel destPacketTableData;
	
	CustomColor customRowColor = new CustomColor();
	
	//constructor to set the frame
	public A2Frame() {
		super("A2");
		setFont(font1);
		Container contentPane = this.getContentPane();
		setSize(1000,500);
		setLayout(new FlowLayout());///change flow to grid
		setMenu();
		RadioButtonPanel();
		setComboBox(); 
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);	
		
		/*source host Ip table initialization*/
		srcTable = new JTable();
		JScrollPane sp = new JScrollPane(srcTable); 
		sp.setVisible(true);
		srcTable.setModel(new MyModel());
		//saveFileChanges();
		srcTable.setPreferredScrollableViewportSize(new Dimension(900,450));
        srcTable.setFillsViewportHeight(true);
		srcTablePanel.add(sp);
		add(srcTablePanel);
		
		/*destination host Ip table initialization*/
		destTable = new JTable();
		JScrollPane sP = new JScrollPane(destTable); 
		sP.setVisible(true);
		destTable.setModel(new MyModel());
		//saveFileChanges();
		destTable.setPreferredScrollableViewportSize(new Dimension(900,450));
        destTable.setFillsViewportHeight(true);
		destTablePanel.add(sP);
		add(destTablePanel);
		
		
	}
	public void setMenu() {
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);	
		JMenu fileMenu = new JMenu("File");
		fileMenu.setMnemonic('F');	
		menuBar.add(fileMenu);
		//file menu
		JMenuItem openFile = new JMenuItem("Open File Trace");
		comboBoxPanel.setVisible(false);////invisible at first
		srcTablePanel.setVisible(false);
		destTablePanel.setVisible(false);
		openFile.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e) {
						fc = new JFileChooser(".");
						//only allow text file
						FileNameExtensionFilter filter = new FileNameExtensionFilter("TEXT FILES", "txt", "text");
						fc.setFileFilter(filter);
						int rVal = fc.showOpenDialog(A2Frame.this);
						
						if (rVal == JFileChooser.APPROVE_OPTION) {
				            File file = fc.getSelectedFile();
				            comboBoxPanel.setVisible(true);//comboBox visible after choosing the file
				            readFile = new Simulator(file); 
				            
				            packetArrayList = readFile.getValidPackets();
				            
				            srcHostArr = readFile.getUniqueSortedSourceHosts();//get unique sorted sourceIp data into sourceHostComboBox
				            destHostArr = readFile.getUniqueSortedDestHosts();// get unique sorted destinationIp data into destHostComboBox
				            
				            if (radioButtonSource.isSelected()) { //if select source host button
				            	destHostComboBox.setVisible(false);
								srcHostComboBox.setVisible(true);
								srcTablePanel.setVisible(true);//show sourceIp table
				            	if (srcHostArr.length > 0) {
					            	System.out.println(srcHostArr.length + "SrcHostArr.length");
					            	for (int i = 0; i < srcHostArr.length; i++) {
					            		srcHostComboBox.addItem(((Host)srcHostArr[i]).getIp());	//adding items into sourceIp combo box
					        		}
					            	srcHostComboBox.setSelectedIndex(0);
					            }
				            }
				            else {									//if select destination host button
				            	srcHostComboBox.setVisible(false);
								destHostComboBox.setVisible(true);
								destTablePanel.setVisible(true);// show destIp table
					            if (destHostArr.length>0) {
					            	for (int i = 0; i < destHostArr.length; i++) {
					            		destHostComboBox.addItem(((Host)destHostArr[i]).getIp()); //adding items into destinationIp combo box
					        		}
					            	destHostComboBox.setSelectedIndex(0);
					            }
				            }
						}						
					}});
	
		JMenuItem quitFile = new JMenuItem("Quit");//Quit button in menu bar
		quitFile.addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e) {
						System.exit(0);
					}
				});
		
		fileMenu.add(openFile);
		fileMenu.add(quitFile);	
	}
	public void RadioButtonPanel() {
		radioButtonGroup = new ButtonGroup();
		radioButtonPanel = new JPanel();
		
		radioButtonPanel.setLayout(new GridBagLayout());
		radioButtonPanel.setPreferredSize(new Dimension(1000, 100));
		radioButtonPanel.setLocation(0,0);
		
		GridBagConstraints d = new GridBagConstraints(); 
		d.gridx = 0; 
		d.gridy = 1; 
		d.anchor = GridBagConstraints.WEST;
		GridBagConstraints s = new GridBagConstraints(); 
		s.gridx = 0; 
		s.gridy = 0; 
		s.weightx = 1;
		s.anchor = GridBagConstraints.WEST;
		///////Source Hosts Radio Button
		radioButtonSource = new JRadioButton("Source Hosts");
		radioButtonSource.setSelected(true);///DEFAULT: "Source Host" button 
		radioButtonSource.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				destHostComboBox.setVisible(false);
				srcHostComboBox.setVisible(true);
				destTablePanel.setVisible(false);//set destTablePanel invisible when select sourceIp button
				srcTablePanel.setVisible(true);
				if (srcHostArr.length > 0) {
	            	System.out.println(srcHostArr.length);
	            	for (int i = 0; i < srcHostArr.length; i++) {
	            		srcHostComboBox.addItem(((Host)srcHostArr[i]).getIp());
	        		}
	            }
			}
		});
		//////Destination Hosts Radio Button
		radioButtonDest = new JRadioButton("Destination Hosts");
		radioButtonDest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				srcHostComboBox.setVisible(false);
				destHostComboBox.setVisible(true);
				destTablePanel.setVisible(true);
				srcTablePanel.setVisible(false);//set srcTablePanel invisible when select destinationIp button
				if (destHostArr.length>0) {
	            	for (int i = 0; i < destHostArr.length; i++) {
	            		destHostComboBox.addItem(((Host)destHostArr[i]).getIp());
	        		}
	            }
			}
		});
		radioButtonPanel.add(radioButtonSource);
		radioButtonPanel.add(radioButtonDest);
		add(radioButtonPanel);
		
		radioButtonGroup.add(radioButtonSource);
		radioButtonGroup.add(radioButtonDest);	
	}
	public void setComboBox() {
		srcHostComboBox = new JComboBox<String>();
        destHostComboBox = new JComboBox<String>();
		
		comboBoxPanel.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints(); 
		c.fill = GridBagConstraints.RELATIVE;
		c.gridx = 0;
		c.gridy = 0;
		
		comboBoxPanel.add(srcHostComboBox, c);
		comboBoxPanel.add(destHostComboBox);
		
		////srcHostComboBox 
		srcHostComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				DefaultTableModel model = (DefaultTableModel) srcTable.getModel();
				
				sourceIpSelected = (String) srcHostComboBox.getSelectedItem();
				
				srcPacketList = readFile.getTableData(sourceIpSelected, isSrcHost);
				srcPacketTableData = new PacketTableModel(srcPacketList, isSrcHost);
				
				//drawTable for sourceIp
				model.setColumnCount(0);
				model.setRowCount(0);
				model.addColumn("Time Stamp");
				model.addColumn("Destination Host Ip Address");	
				model.addColumn("Ip Packet Size");

				//get table data from srcPacketTableData (Class PacketTableData)
				
				for(int x = 0;x<srcPacketTableData.getRowCount(); x++) {
					Object obj = "";
					ArrayList <Object> objArrList = new ArrayList <Object> ();
					for (int y = 0; y<srcPacketTableData.getColumnCount(); y++) {
						obj = srcPacketTableData.getValueAt(x, y);
						objArrList.add(obj);
					}
					model.addRow(objArrList.toArray());
					
				}
				customRowColor.setColorRow(srcPacketTableData.getRowCount());//change the color of last 2 rows
				srcTable.setDefaultRenderer(Object.class, customRowColor);
				
			}});
		
		////destHostComboBox
		destHostComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String destIpSelected = (String) destHostComboBox.getSelectedItem(); 
				
				destPacketList = readFile.getTableData(destIpSelected, false);
				destPacketTableData = new PacketTableModel(destPacketList, false);
				//drawTable for destinationIp
				DefaultTableModel model = (DefaultTableModel) destTable.getModel();
				
				model.setColumnCount(0);
				model.setRowCount(0);
				model.addColumn("Time Stamp");
				model.addColumn("Source Host Ip Address");	
				model.addColumn("Ip Packet Size");
				//get table data from destPacketTableData (Class PacketTableData)
				for(int x = 0;x<destPacketTableData.getRowCount(); x++) {
					Object obj = "";
					ArrayList <Object> objArrList = new ArrayList <Object> ();
					for (int y = 0; y<destPacketTableData.getColumnCount(); y++) {
						obj = destPacketTableData.getValueAt(x, y);
						objArrList.add(obj);
					}
					model.addRow(objArrList.toArray());
				}
				
				System.out.println(destIpSelected);
			}});
		add(comboBoxPanel);
	}
	public void saveFileChanges() {//save changes to original text files
		fc.setDialogTitle("Specify a file to save");   
		 
		int userSelection = fc.showSaveDialog(A2Frame.this);
		 
		if (userSelection == JFileChooser.APPROVE_OPTION) {
		    File fileToSave = fc.getSelectedFile();
		    System.out.println("Save as file: " + fileToSave.getAbsolutePath());
		}
	}
		
}

