
import javax.swing.table.DefaultTableModel;

public class MyModel extends DefaultTableModel { //allow make changes to Ip packet size

    public boolean isCellEditable(int row, int column){  
        if (column == 2 && row < getRowCount() - 2)
        	return true;
    	return false;  
    }

}